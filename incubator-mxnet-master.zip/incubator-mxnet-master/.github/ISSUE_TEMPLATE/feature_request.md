---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'Feature request'
assignees: ''

---

## Description
(A clear and concise description of what the feature is.)
- If the proposal is about a new model, provide description of what the model is.
- If the proposal is about an API, provide mock examples if possible.

## References
- list reference and related literature
- list known implementations
